import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import ImageUpload from "@/components/ImageUpload";
import { 
  Plus, 
  Heart, 
  MessageCircle, 
  Share2, 
  Bookmark,
  MapPin,
  Users,
  TrendingUp,
  Filter
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { formatDistanceToNow } from "date-fns";
import Layout from "@/components/Layout";

export default function Community() {
  const [newPost, setNewPost] = useState({
    title: "",
    content: "",
    destination: "",
    imageUrl: "",
  });
  const [selectedDestination, setSelectedDestination] = useState<string>("");
  const [showCreatePost, setShowCreatePost] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch posts
  const { data: posts = [], isLoading: postsLoading } = useQuery({
    queryKey: ["/api/posts", selectedDestination],
    retry: false,
  });

  // Fetch popular destinations
  const { data: popularDestinations = [] } = useQuery({
    queryKey: ["/api/destinations/popular"],
    retry: false,
  });

  const createPostMutation = useMutation({
    mutationFn: async (postData: any) => {
      await apiRequest("POST", "/api/posts", postData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/destinations/popular"] });
      toast({
        title: "Post Created",
        description: "Your travel story has been shared with the community.",
      });
      setNewPost({ title: "", content: "", destination: "", imageUrl: "" });
      setShowCreatePost(false);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create post. Please try again.",
        variant: "destructive",
      });
    },
  });

  const toggleLikeMutation = useMutation({
    mutationFn: async (postId: number) => {
      await apiRequest("POST", `/api/posts/${postId}/like`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    },
  });

  const handleCreatePost = () => {
    if (!newPost.title.trim() || !newPost.content.trim()) {
      toast({
        title: "Fehlende Informationen",
        description: "Bitte füllen Sie sowohl Titel als auch Inhalt aus.",
        variant: "destructive",
      });
      return;
    }

    createPostMutation.mutate(newPost);
  };

  return (
    <Layout activeSection="community" onSectionChange={() => {}}>
      <div className="min-h-screen bg-gray-50 px-4 py-6 pb-24">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Reise-Community</h1>
              <p className="text-gray-600">Starke Community-Funktionen mit Expertenkanälen & Gruppenplanung</p>
            </div>
            <Button 
              onClick={() => setShowCreatePost(true)}
              className="bg-blue-600 hover:bg-blue-700"
              size="sm"
            >
              <Plus className="w-4 h-4" />
            </Button>
          </div>

          {/* Popular Destinations */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5" />
                <span>Beliebte Reiseziele</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                <Badge
                  variant={selectedDestination === "" ? "default" : "secondary"}
                  className="cursor-pointer"
                  onClick={() => setSelectedDestination("")}
                >
                  All Destinations
                </Badge>
                {Array.isArray(popularDestinations) && popularDestinations.map((dest: any) => (
                  <Badge
                    key={dest.destination}
                    variant={selectedDestination === dest.destination ? "default" : "secondary"}
                    className="cursor-pointer"
                    onClick={() => setSelectedDestination(dest.destination)}
                  >
                    {dest.destination} ({dest.postCount})
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Posts */}
          <div className="space-y-4">
            {postsLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <Card key={i} className="animate-pulse">
                    <CardContent className="p-6">
                      <div className="flex items-center space-x-3 mb-4">
                        <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                        <div className="flex-1">
                          <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
                          <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                        </div>
                      </div>
                      <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                      <div className="h-32 bg-gray-200 rounded"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : Array.isArray(posts) && posts.length === 0 ? (
              <Card>
                <CardContent className="text-center py-12">
                  <Users className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No posts yet</h3>
                  <p className="text-gray-600 mb-4">
                    Be the first to share your travel experience!
                  </p>
                  <Button 
                    onClick={() => setShowCreatePost(true)}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    Create First Post
                  </Button>
                </CardContent>
              </Card>
            ) : (
              Array.isArray(posts) && posts.map((post: any) => (
                <Card key={post.id} className="overflow-hidden">
                  <CardContent className="p-0">
                    {/* Post Header */}
                    <div className="p-4 pb-0">
                      <div className="flex items-center space-x-3 mb-3">
                        <Avatar className="w-10 h-10">
                          <AvatarImage src={post.author?.profileImageUrl} />
                          <AvatarFallback>
                            {post.author?.firstName?.[0] || post.author?.email?.[0] || "U"}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <p className="font-medium text-gray-900">
                              {post.author?.firstName || "Anonymous"}
                            </p>
                            {post.destination && (
                              <Badge variant="outline" className="text-xs">
                                <MapPin className="w-3 h-3 mr-1" />
                                {post.destination}
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-gray-500">
                            {formatDistanceToNow(new Date(post.createdAt))} ago
                          </p>
                        </div>
                      </div>
                      
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        {post.title}
                      </h3>
                      <p className="text-gray-700 mb-3 leading-relaxed">
                        {post.content}
                      </p>
                    </div>

                    {/* Post Image */}
                    {post.imageUrl && (
                      <div className="px-4 mb-3">
                        <img 
                          src={post.imageUrl} 
                          alt={post.title}
                          className="w-full h-64 object-cover rounded-lg"
                        />
                      </div>
                    )}

                    {/* Post Actions */}
                    <div className="px-4 pb-4">
                      <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                        <div className="flex items-center space-x-4">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => toggleLikeMutation.mutate(post.id)}
                            className="text-gray-600 hover:text-red-600"
                          >
                            <Heart className="w-4 h-4 mr-1" />
                            {post.likesCount || 0}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-gray-600"
                          >
                            <MessageCircle className="w-4 h-4 mr-1" />
                            {post.commentsCount || 0}
                          </Button>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-gray-600"
                        >
                          <Share2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>

          {/* Create Post Dialog */}
          <Dialog open={showCreatePost} onOpenChange={setShowCreatePost}>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Share Your Travel Story</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="post-title">Title</Label>
                  <Input
                    id="post-title"
                    placeholder="Amazing sunset in Bali..."
                    value={newPost.title}
                    onChange={(e) => setNewPost(prev => ({ ...prev, title: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="post-destination">Destination</Label>
                  <Input
                    id="post-destination"
                    placeholder="Bali, Indonesia"
                    value={newPost.destination}
                    onChange={(e) => setNewPost(prev => ({ ...prev, destination: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="post-content">Share your experience</Label>
                  <Textarea
                    id="post-content"
                    placeholder="Tell us about your adventure..."
                    value={newPost.content}
                    onChange={(e) => setNewPost(prev => ({ ...prev, content: e.target.value }))}
                    rows={4}
                  />
                </div>
                <div>
                  <Label>Photo (Optional)</Label>
                  <ImageUpload
                    onImageSelect={(imageUrl) => setNewPost(prev => ({ ...prev, imageUrl }))}
                    currentImage={newPost.imageUrl}
                    className="mt-2"
                  />
                </div>
                <div className="flex space-x-3">
                  <Button variant="outline" onClick={() => setShowCreatePost(false)} className="flex-1">
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleCreatePost}
                    disabled={createPostMutation.isPending}
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                  >
                    {createPostMutation.isPending ? "Posting..." : "Share Post"}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </Layout>
  );
}