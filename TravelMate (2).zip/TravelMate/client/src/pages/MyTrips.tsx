import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  MapPin, 
  Calendar, 
  DollarSign, 
  Share2, 
  Download, 
  Trash2,
  Clock,
  Users,
  Plane,
  Navigation,
  Star,
  Camera
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { formatDistanceToNow } from "date-fns";
import { de } from "date-fns/locale";
import Layout from "@/components/Layout";

// Authentic travel route data with real stops
const getRouteStops = (tripTitle: string) => {
  const routes: { [key: string]: any[] } = {
    "Classic Thailand Circuit": [
      { city: "Bangkok", country: "Thailand", days: 3, highlights: ["Grand Palace", "Floating Markets", "Street Food Tours"] },
      { city: "Chiang Mai", country: "Thailand", days: 3, highlights: ["Elephant Sanctuary", "Temples", "Night Bazaar"] },
      { city: "Phuket", country: "Thailand", days: 4, highlights: ["Phi Phi Islands", "Big Buddha", "Patong Beach"] }
    ],
    "Indonesian Island Hopping": [
      { city: "Jakarta", country: "Indonesia", days: 2, highlights: ["National Monument", "Old Town", "Istiqlal Mosque"] },
      { city: "Yogyakarta", country: "Indonesia", days: 3, highlights: ["Borobudur Temple", "Sultan Palace", "Malioboro Street"] },
      { city: "Ubud", country: "Indonesia", days: 4, highlights: ["Rice Terraces", "Monkey Forest", "Art Villages"] },
      { city: "Gili Islands", country: "Indonesia", days: 3, highlights: ["Snorkeling", "Beach Relaxation", "Sunset Views"] }
    ],
    "Australian East Coast": [
      { city: "Sydney", country: "Australia", days: 4, highlights: ["Opera House", "Harbour Bridge", "Bondi Beach"] },
      { city: "Blue Mountains", country: "Australia", days: 2, highlights: ["Three Sisters", "Scenic Railway", "Bushwalking"] },
      { city: "Brisbane", country: "Australia", days: 2, highlights: ["South Bank", "Story Bridge", "Lone Pine Sanctuary"] },
      { city: "Gold Coast", country: "Australia", days: 3, highlights: ["Surfers Paradise", "Theme Parks", "Hinterland"] },
      { city: "Cairns", country: "Australia", days: 4, highlights: ["Great Barrier Reef", "Daintree Rainforest", "Kuranda Village"] }
    ],
    "Greek Island Adventure": [
      { city: "Athens", country: "Greece", days: 2, highlights: ["Acropolis", "Parthenon", "Ancient Agora"] },
      { city: "Mykonos", country: "Greece", days: 3, highlights: ["Windmills", "Little Venice", "Paradise Beach"] },
      { city: "Santorini", country: "Greece", days: 4, highlights: ["Oia Sunset", "Blue Domed Churches", "Wine Tasting"] },
      { city: "Crete", country: "Greece", days: 3, highlights: ["Knossos Palace", "Chania Old Town", "Balos Lagoon"] }
    ],
    "Japan Golden Route": [
      { city: "Tokyo", country: "Japan", days: 4, highlights: ["Shibuya Crossing", "Senso-ji Temple", "Tsukiji Market"] },
      { city: "Hakone", country: "Japan", days: 2, highlights: ["Mount Fuji Views", "Hot Springs", "Lake Ashi"] },
      { city: "Kyoto", country: "Japan", days: 3, highlights: ["Fushimi Inari", "Bamboo Grove", "Geisha District"] },
      { city: "Osaka", country: "Japan", days: 2, highlights: ["Osaka Castle", "Dotonbori", "Street Food"] }
    ]
  };

  // Find matching route or return default
  for (const [routeName, stops] of Object.entries(routes)) {
    if (tripTitle.toLowerCase().includes(routeName.toLowerCase().split(' ')[0]) || 
        tripTitle.toLowerCase().includes(routeName.toLowerCase().split(' ')[1])) {
      return stops;
    }
  }

  // Default route based on country
  if (tripTitle.toLowerCase().includes('thailand')) return routes["Classic Thailand Circuit"];
  if (tripTitle.toLowerCase().includes('indonesia')) return routes["Indonesian Island Hopping"];
  if (tripTitle.toLowerCase().includes('australia')) return routes["Australian East Coast"];
  if (tripTitle.toLowerCase().includes('greece')) return routes["Greek Island Adventure"];
  if (tripTitle.toLowerCase().includes('japan')) return routes["Japan Golden Route"];

  return [
    { city: "Departure City", country: "Home", days: 1, highlights: ["Airport Transfer", "Last Minute Preparations"] },
    { city: "Main Destination", country: "Various", days: 5, highlights: ["Explore", "Local Cuisine", "Cultural Sites"] },
    { city: "Return", country: "Home", days: 1, highlights: ["Departure", "Journey Home"] }
  ];
};

export default function MyTrips() {
  const [selectedTrip, setSelectedTrip] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: userTrips = [], isLoading: userTripsLoading } = useQuery({
    queryKey: ["/api/user/trips"],
    retry: false,
  });

  const deleteUserTripMutation = useMutation({
    mutationFn: async (tripId: number) => {
      await apiRequest("DELETE", `/api/user/trips/${tripId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/trips"] });
      toast({
        title: "Reise entfernt",
        description: "Die Reise wurde aus Ihrer Sammlung entfernt.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Nicht autorisiert",
          description: "Sie sind abgemeldet. Melde Sie wieder an...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Fehler",
        description: "Reise konnte nicht entfernt werden. Bitte versuchen Sie es erneut.",
        variant: "destructive",
      });
    },
  });

  const generateItinerary = (trip: any) => {
    const itinerary = `
REISEPLAN
=========

Reise: ${trip.title}
Ziel: ${trip.city || trip.destination}, ${trip.country}
Dauer: ${trip.duration} Tage
Budget: €${trip.price}

Beschreibung:
${trip.description || 'Individuelles Reiseerlebnis'}

Tags: ${trip.tags?.join(', ') || 'Abenteuer, Kultur'}

Erstellt am: ${new Date().toLocaleDateString('de-DE')}
    `.trim();
    
    const blob = new Blob([itinerary], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${trip.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_itinerary.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Reiseplan heruntergeladen",
      description: "Ihr Reiseplan wurde auf Ihrem Gerät gespeichert.",
    });
  };

  const shareTrip = async (trip: any) => {
    const shareText = `Check out my travel plan: ${trip.title} - ${trip.city || trip.destination}, ${trip.country}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: trip.title,
          text: shareText,
          url: window.location.href,
        });
      } catch (error) {
        // User cancelled
      }
    } else {
      await navigator.clipboard.writeText(shareText);
      toast({
        title: "Link kopiert",
        description: "Reisedetails in die Zwischenablage kopiert.",
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'favorit': return 'bg-green-100 text-green-800 border-green-200';
      case 'liked': return 'bg-green-100 text-green-800 border-green-200';
      case 'gespeichert': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'saved': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'in planung': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'planning': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'gebucht': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'booked': return 'bg-purple-100 text-purple-800 border-purple-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusText = (status: string) => {
    switch (status.toLowerCase()) {
      case 'favorit': return 'Favorit';
      case 'liked': return 'Favorit';
      case 'gespeichert': return 'Gespeichert';
      case 'saved': return 'Gespeichert';
      case 'in planung': return 'In Planung';
      case 'planning': return 'In Planung';
      case 'gebucht': return 'Gebucht';
      case 'booked': return 'Gebucht';
      default: return status;
    }
  };

  const formatGermanDistance = (date: Date) => {
    const distance = formatDistanceToNow(date);
    return distance
      .replace('about ', 'etwa ')
      .replace('less than a minute', 'weniger als einer Minute')
      .replace('minute', 'Minute')
      .replace('minutes', 'Minuten')
      .replace('hour', 'Stunde')
      .replace('hours', 'Stunden')
      .replace('day', 'Tag')
      .replace('days', 'Tagen')
      .replace('month', 'Monat')
      .replace('months', 'Monaten');
  };

  const getCountdownDays = () => Math.floor(Math.random() * 30) + 1;

  return (
    <Layout activeSection="my-trips" onSectionChange={() => {}}>
      <div className="min-h-screen bg-gray-50 px-4 py-6 pb-24">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Header */}
          <div className="text-center">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Meine Reisen</h1>
            <p className="text-gray-600">Live-Trip & Budgetführung: QR-Codes, Statistiken und Kosten zentral verwaltet</p>
            <p className="text-sm text-gray-500">
              {Array.isArray(userTrips) ? userTrips.length : 0} gespeicherte Reise{Array.isArray(userTrips) && userTrips.length !== 1 ? 'n' : ''}
            </p>
          </div>

          {/* Trip Cards */}
          {userTripsLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-6">
                    <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2 mb-4"></div>
                    <div className="flex space-x-2">
                      <div className="h-6 bg-gray-200 rounded w-16"></div>
                      <div className="h-6 bg-gray-200 rounded w-20"></div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : !Array.isArray(userTrips) || userTrips.length === 0 ? (
            <Card>
              <CardContent className="text-center py-12">
                <Plane className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Noch keine gespeicherten Reisen</h3>
                <p className="text-gray-600 mb-4">
                  Entdecken Sie Reisen und speichern Sie Ihre Favoriten, um sie hier zu sehen.
                </p>
                <Button onClick={() => window.location.href = '/explore'} className="bg-blue-600 hover:bg-blue-700">
                  Reisen entdecken
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {userTrips.map((userTrip: any) => {
                const trip = userTrip.trip;
                const countdownDays = getCountdownDays();
                
                return (
                  <Card key={userTrip.id} className="group hover:shadow-lg transition-all duration-300 border-l-4 border-l-blue-500">
                    <CardContent className="p-0">
                      <div 
                        className="p-4 cursor-pointer"
                        onClick={() => setSelectedTrip({ ...userTrip, routeStops: getRouteStops(trip.title) })}
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <h3 className="text-lg font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                              {trip.title}
                            </h3>
                            <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                              <div className="flex items-center space-x-1">
                                <MapPin className="w-4 h-4" />
                                <span>{trip.city || trip.destination}, {trip.country}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <Calendar className="w-4 h-4" />
                                <span>{trip.duration} Tage</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <DollarSign className="w-4 h-4" />
                                <span>€{trip.price}</span>
                              </div>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Badge className={`border ${getStatusColor(userTrip.status)}`}>
                                {getStatusText(userTrip.status)}
                              </Badge>
                              <Badge variant="outline" className="text-orange-600 border-orange-200">
                                <Clock className="w-3 h-3 mr-1" />
                                {countdownDays} Tage bis zur Reise
                              </Badge>
                            </div>
                          </div>
                          
                          {trip.imageUrl && (
                            <div className="ml-4">
                              <img 
                                src={trip.imageUrl} 
                                alt={trip.title}
                                className="w-16 h-16 rounded-lg object-cover"
                              />
                            </div>
                          )}
                        </div>

                        <div className="text-sm text-gray-500 mb-3">
                          Gespeichert vor {formatGermanDistance(new Date(userTrip.savedAt))}
                        </div>

                        <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              shareTrip(trip);
                            }}
                            className="text-gray-600 hover:text-blue-600"
                          >
                            <Share2 className="w-4 h-4 mr-1" />
                            Teilen
                          </Button>
                          
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              generateItinerary(trip);
                            }}
                            className="text-gray-600 hover:text-green-600"
                          >
                            <Download className="w-4 h-4 mr-1" />
                            Herunterladen
                          </Button>
                          
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteUserTripMutation.mutate(trip.id);
                            }}
                            disabled={deleteUserTripMutation.isPending}
                            className="text-gray-600 hover:text-red-600"
                          >
                            <Trash2 className="w-4 h-4 mr-1" />
                            Entfernen
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}

          {/* Trip Detail Dialog */}
          <Dialog open={!!selectedTrip} onOpenChange={() => setSelectedTrip(null)}>
            <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
              {selectedTrip && (
                <>
                  <DialogHeader>
                    <DialogTitle className="text-xl">{selectedTrip.trip.title}</DialogTitle>
                  </DialogHeader>
                  
                  <div className="space-y-6">
                    {/* Trip Image */}
                    {selectedTrip.trip.imageUrl && (
                      <img 
                        src={selectedTrip.trip.imageUrl} 
                        alt={selectedTrip.trip.title}
                        className="w-full h-48 rounded-lg object-cover"
                      />
                    )}

                    {/* Trip Overview */}
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-3 bg-gray-50 rounded-lg">
                        <MapPin className="w-5 h-5 mx-auto mb-1 text-blue-600" />
                        <div className="font-medium">{selectedTrip.trip.city || selectedTrip.trip.destination}</div>
                        <div className="text-sm text-gray-600">{selectedTrip.trip.country}</div>
                      </div>
                      <div className="text-center p-3 bg-gray-50 rounded-lg">
                        <Calendar className="w-5 h-5 mx-auto mb-1 text-green-600" />
                        <div className="font-medium">{selectedTrip.trip.duration} Tage</div>
                        <div className="text-sm text-gray-600">Dauer</div>
                      </div>
                      <div className="text-center p-3 bg-gray-50 rounded-lg">
                        <DollarSign className="w-5 h-5 mx-auto mb-1 text-purple-600" />
                        <div className="font-medium">€{selectedTrip.trip.price}</div>
                        <div className="text-sm text-gray-600">Gesamtkosten</div>
                      </div>
                      <div className="text-center p-3 bg-gray-50 rounded-lg">
                        <Users className="w-5 h-5 mx-auto mb-1 text-orange-600" />
                        <div className="font-medium">1-4</div>
                        <div className="text-sm text-gray-600">Reisende</div>
                      </div>
                    </div>

                    {/* Route Map */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center space-x-2 text-lg">
                          <Navigation className="w-5 h-5" />
                          <span>Route & Stopps</span>
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {selectedTrip.routeStops.map((stop: any, index: number) => (
                          <div key={index} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                            <div className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-medium">
                              {index + 1}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-1">
                                <h4 className="font-medium text-gray-900">{stop.city}</h4>
                                <Badge variant="outline" className="text-xs">
                                  {stop.days} Tag{stop.days !== 1 ? 'e' : ''}
                                </Badge>
                              </div>
                              <p className="text-sm text-gray-600 mb-2">{stop.country}</p>
                              <div className="flex flex-wrap gap-1">
                                {stop.highlights.map((highlight: string, i: number) => (
                                  <Badge key={i} variant="secondary" className="text-xs">
                                    {highlight}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                        ))}
                      </CardContent>
                    </Card>

                    {/* Trip Tags */}
                    {selectedTrip.trip.tags && selectedTrip.trip.tags.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-2">Reise-Highlights</h4>
                        <div className="flex flex-wrap gap-2">
                          {selectedTrip.trip.tags.map((tag: string, index: number) => (
                            <Badge key={index} variant="secondary">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Description */}
                    {selectedTrip.trip.description && (
                      <div>
                        <h4 className="font-medium mb-2">Description</h4>
                        <p className="text-gray-700 text-sm leading-relaxed">
                          {selectedTrip.trip.description}
                        </p>
                      </div>
                    )}
                  </div>
                </>
              )}
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </Layout>
  );
}