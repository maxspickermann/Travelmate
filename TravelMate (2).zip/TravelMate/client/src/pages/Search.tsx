import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Search as SearchIcon, 
  MapPin, 
  Calendar, 
  DollarSign, 
  Users, 
  Sparkles,
  Plus,
  X
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Layout from "@/components/Layout";

const travelStyles = [
  "Abenteuer", "Kultur", "Entspannung", "Nachtleben", "Essen", 
  "Fotografie", "Romantik", "Familie", "Budget", "Luxus",
  "Backpacking", "Wellness", "Sport", "Natur", "Städtereise",
  "Strandurlaub", "Wintersport", "Roadtrip", "Kreuzfahrt", "Safari",
  "Wandern", "Tauchen", "Surfen", "Yoga", "Meditation",
  "Geschichte", "Architektur", "Kunst", "Musik", "Festivals"
];

const topDestinations = [
  "Spanien", "Italien", "Frankreich", "Griechenland", "Türkei", 
  "Portugal", "Kroatien", "Thailand", "USA", "Japan"
];

const allCountries = [
  "Afghanistan", "Albanien", "Algerien", "Andorra", "Angola", "Antigua und Barbuda", "Argentinien", "Armenien", "Australien", "Österreich",
  "Aserbaidschan", "Bahamas", "Bahrain", "Bangladesch", "Barbados", "Belarus", "Belgien", "Belize", "Benin", "Bhutan",
  "Bolivien", "Bosnien und Herzegowina", "Botswana", "Brasilien", "Brunei", "Bulgarien", "Burkina Faso", "Burundi", "Kambodscha", "Kamerun",
  "Kanada", "Kap Verde", "Zentralafrikanische Republik", "Tschad", "Chile", "China", "Kolumbien", "Komoren", "Kongo", "Costa Rica",
  "Kroatien", "Kuba", "Zypern", "Tschechien", "Dänemark", "Dschibuti", "Dominica", "Dominikanische Republik", "Ecuador", "Ägypten",
  "El Salvador", "Äquatorialguinea", "Eritrea", "Estland", "Eswatini", "Äthiopien", "Fidschi", "Finnland", "Frankreich", "Gabun",
  "Gambia", "Georgien", "Deutschland", "Ghana", "Griechenland", "Grenada", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana",
  "Haiti", "Honduras", "Ungarn", "Island", "Indien", "Indonesien", "Iran", "Irak", "Irland", "Israel",
  "Italien", "Jamaika", "Japan", "Jordanien", "Kasachstan", "Kenia", "Kiribati", "Nordkorea", "Südkorea", "Kuwait",
  "Kirgisistan", "Laos", "Lettland", "Libanon", "Lesotho", "Liberia", "Libyen", "Liechtenstein", "Litauen", "Luxemburg",
  "Madagaskar", "Malawi", "Malaysia", "Malediven", "Mali", "Malta", "Marshallinseln", "Mauretanien", "Mauritius", "Mexiko",
  "Mikronesien", "Moldau", "Monaco", "Mongolei", "Montenegro", "Marokko", "Mosambik", "Myanmar", "Namibia", "Nauru",
  "Nepal", "Niederlande", "Neuseeland", "Nicaragua", "Niger", "Nigeria", "Nordmazedonien", "Norwegen", "Oman", "Pakistan",
  "Palau", "Panama", "Papua-Neuguinea", "Paraguay", "Peru", "Philippinen", "Polen", "Portugal", "Katar", "Rumänien",
  "Russland", "Ruanda", "Saint Kitts und Nevis", "Saint Lucia", "Saint Vincent und die Grenadinen", "Samoa", "San Marino", "São Tomé und Príncipe", "Saudi-Arabien", "Senegal",
  "Serbien", "Seychellen", "Sierra Leone", "Singapur", "Slowakei", "Slowenien", "Salomonen", "Somalia", "Südafrika", "Südsudan",
  "Spanien", "Sri Lanka", "Sudan", "Suriname", "Schweden", "Schweiz", "Syrien", "Taiwan", "Tadschikistan", "Tansania",
  "Thailand", "Timor-Leste", "Togo", "Tonga", "Trinidad und Tobago", "Tunesien", "Türkei", "Turkmenistan", "Tuvalu", "Uganda",
  "Ukraine", "Vereinigte Arabische Emirate", "Vereinigtes Königreich", "USA", "Uruguay", "Usbekistan", "Vanuatu", "Vatikanstadt", "Venezuela", "Vietnam",
  "Jemen", "Sambia", "Simbabwe"
];

const durationOptions = [
  { label: "Kurztrip (1-3 Tage)", value: "1-3" },
  { label: "Wochenende (4-7 Tage)", value: "4-7" },
  { label: "1-2 Wochen", value: "7-14" },
  { label: "3-4 Wochen", value: "15-28" },
  { label: "Langzeitreise (1+ Monat)", value: "30+" }
];

const budgetOptions = [
  { label: "Budget (bis 500€)", value: "0-500" },
  { label: "Sparsam (500-1000€)", value: "500-1000" },
  { label: "Mittelklasse (1000-2500€)", value: "1000-2500" },
  { label: "Komfortabel (2500-5000€)", value: "2500-5000" },
  { label: "Luxus (5000€+)", value: "5000+" }
];

export default function Search() {
  const [searchData, setSearchData] = useState({
    countries: [] as string[],
    countrySearch: "",
    freeSearch: "",
    durationType: "",
    customDuration: "",
    startDate: "",
    endDate: "",
    budgetType: "",
    customBudget: "",
    travelPeriod: "",
    groupSize: "",
    travelStyles: [] as string[],
    additionalNotes: ""
  });
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createTripMutation = useMutation({
    mutationFn: async (tripData: any) => {
      return await apiRequest("POST", "/api/trips", tripData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/trips"] });
      toast({
        title: "Trip Created",
        description: "Your custom trip has been created and saved to My Trips.",
      });
      // Reset form
      setSearchData({
        destination: "",
        freeSearch: "",
        duration: "",
        minBudget: 500,
        maxBudget: 5000,
        travelPeriod: "",
        groupSize: "",
        travelStyles: [],
        additionalNotes: ""
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create trip. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCountryToggle = (country: string) => {
    setSearchData(prev => ({
      ...prev,
      countries: prev.countries.includes(country)
        ? prev.countries.filter(c => c !== country)
        : [...prev.countries, country]
    }));
  };

  const handleStyleToggle = (style: string) => {
    setSearchData(prev => ({
      ...prev,
      travelStyles: prev.travelStyles.includes(style)
        ? prev.travelStyles.filter(s => s !== style)
        : [...prev.travelStyles, style]
    }));
  };

  const filteredCountries = allCountries.filter(country => 
    country.toLowerCase().includes(searchData.countrySearch.toLowerCase())
  );

  const handleCreateTrip = () => {
    // Build title from search criteria
    let title = "Individuelle Reise";
    if (searchData.countries.length > 0) {
      title = `Reise nach ${searchData.countries.join(", ")}`;
    } else if (searchData.freeSearch) {
      title = searchData.freeSearch;
    }

    // Build description from all inputs
    const description = [
      searchData.additionalNotes,
      searchData.travelStyles.length > 0 && `Reisestil: ${searchData.travelStyles.join(", ")}`,
      searchData.groupSize && `Gruppengröße: ${searchData.groupSize}`,
      searchData.travelPeriod && `Reisezeit: ${searchData.travelPeriod}`
    ].filter(Boolean).join(". ");

    // Calculate duration
    let duration = 7;
    if (searchData.customDuration) {
      duration = parseInt(searchData.customDuration);
    } else if (searchData.durationType) {
      const durationMap: { [key: string]: number } = {
        "1-3": 2,
        "4-7": 5,
        "7-14": 10,
        "15-28": 21,
        "30+": 30
      };
      duration = durationMap[searchData.durationType] || 7;
    }

    // Calculate budget
    let budget = "1500";
    if (searchData.customBudget) {
      budget = searchData.customBudget;
    } else if (searchData.budgetType) {
      const budgetMap: { [key: string]: string } = {
        "0-500": "400",
        "500-1000": "750",
        "1000-2500": "1750",
        "2500-5000": "3750",
        "5000+": "7500"
      };
      budget = budgetMap[searchData.budgetType] || "1500";
    }

    const tripData = {
      title,
      description: description || "Individuell geplante Reise",
      destination: searchData.countries.join(", ") || searchData.freeSearch || "Verschiedene Ziele",
      country: searchData.countries[0] || "Verschiedene",
      region: null,
      city: null,
      duration,
      price: budget,
      tags: searchData.travelStyles,
      imageUrl: null,
      isPublic: false
    };

    createTripMutation.mutate(tripData);
  };

  return (
    <Layout activeSection="search" onSectionChange={() => {}}>
      <div className="min-h-screen bg-gray-50 px-4 py-6 pb-24">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Reiseplanung</h1>
            <p className="text-gray-600">Tiefgestaffelte Planung: von Landebene zu Stadt, bis Platz/Ticket-Ebene</p>
          </div>

          {/* Free Search */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-lg">
                <SearchIcon className="w-5 h-5" />
                <span>Was suchen Sie?</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Freie Suche (beschreiben Sie Ihre Traumreise)</Label>
                <Textarea
                  placeholder="z.B. 'Backpacking durch Südostasien mit Street Food Touren' oder 'Romantisches Wochenende in Paris mit Weinverkostung'"
                  value={searchData.freeSearch}
                  onChange={(e) => setSearchData(prev => ({ ...prev, freeSearch: e.target.value }))}
                  className="mt-2"
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Countries */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-lg">
                <MapPin className="w-5 h-5" />
                <span>Reiseziel(e) (Optional)</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Top Destinations */}
              <div>
                <Label className="text-sm font-medium">Beliebte Ziele</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {topDestinations.map((country) => (
                    <Button
                      key={country}
                      variant={searchData.countries.includes(country) ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleCountryToggle(country)}
                      className="text-xs"
                    >
                      {country}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Country Search */}
              <div>
                <Label className="text-sm font-medium">Land suchen</Label>
                <Input
                  placeholder="Nach Land suchen..."
                  value={searchData.countrySearch}
                  onChange={(e) => setSearchData(prev => ({ ...prev, countrySearch: e.target.value }))}
                  className="mt-2"
                />
              </div>

              {/* Filtered Countries */}
              {searchData.countrySearch && (
                <div className="max-h-32 overflow-y-auto">
                  <div className="grid grid-cols-2 gap-1">
                    {filteredCountries.slice(0, 20).map((country) => (
                      <Button
                        key={country}
                        variant={searchData.countries.includes(country) ? "default" : "ghost"}
                        size="sm"
                        onClick={() => handleCountryToggle(country)}
                        className="justify-start text-xs"
                      >
                        {country}
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              {/* Selected Countries */}
              {searchData.countries.length > 0 && (
                <div>
                  <Label className="text-sm font-medium">Ausgewählte Länder</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {searchData.countries.map((country) => (
                      <Badge key={country} variant="secondary" className="cursor-pointer" onClick={() => handleCountryToggle(country)}>
                        {country} ×
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Interactive Map */}
              {searchData.countries.length > 0 && (
                <div className="mt-4">
                  <Label className="text-sm font-medium">Kartenansicht</Label>
                  <div className="mt-2 h-48 bg-gray-100 rounded-lg flex items-center justify-center">
                    <div className="text-center text-gray-500">
                      <MapPin className="w-8 h-8 mx-auto mb-2" />
                      <p className="text-sm">Interaktive Karte für {searchData.countries.join(", ")}</p>
                      <p className="text-xs">Route wird automatisch geplant</p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Duration */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-lg">
                <Calendar className="w-5 h-5" />
                <span>Reisedauer (Optional)</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Predefined Duration Options */}
              <div>
                <Label className="text-sm font-medium">Vordefinierte Zeiträume</Label>
                <div className="grid grid-cols-1 gap-2 mt-2">
                  {durationOptions.map((option) => (
                    <Button
                      key={option.value}
                      variant={searchData.durationType === option.value ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSearchData(prev => ({ ...prev, durationType: option.value, customDuration: "", startDate: "", endDate: "" }))}
                      className="justify-start text-xs"
                    >
                      {option.label}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Custom Duration Input */}
              <div>
                <Label className="text-sm font-medium">Oder individuelle Eingabe</Label>
                <div className="space-y-2 mt-2">
                  <Input
                    placeholder="Anzahl Tage (z.B. 12)"
                    value={searchData.customDuration}
                    onChange={(e) => setSearchData(prev => ({ ...prev, customDuration: e.target.value, durationType: "", startDate: "", endDate: "" }))}
                    type="number"
                    min="1"
                  />
                  <div className="text-xs text-gray-500 text-center">oder</div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label className="text-xs">Startdatum</Label>
                      <Input
                        type="date"
                        value={searchData.startDate}
                        onChange={(e) => setSearchData(prev => ({ ...prev, startDate: e.target.value, durationType: "", customDuration: "" }))}
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Enddatum</Label>
                      <Input
                        type="date"
                        value={searchData.endDate}
                        onChange={(e) => setSearchData(prev => ({ ...prev, endDate: e.target.value, durationType: "", customDuration: "" }))}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Group Size */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-lg">
                <Users className="w-5 h-5" />
                <span>Gruppengröße (Optional)</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Select value={searchData.groupSize} onValueChange={(value) => 
                setSearchData(prev => ({ ...prev, groupSize: value }))
              }>
                <SelectTrigger>
                  <SelectValue placeholder="Wie viele Reisende?" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="solo">Solo (1 Person)</SelectItem>
                  <SelectItem value="couple">Paar (2 Personen)</SelectItem>
                  <SelectItem value="small">Kleine Gruppe (3-5 Personen)</SelectItem>
                  <SelectItem value="large">Große Gruppe (6+ Personen)</SelectItem>
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {/* Budget */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-lg">
                <DollarSign className="w-5 h-5" />
                <span>Budget (Optional)</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Predefined Budget Options */}
              <div>
                <Label className="text-sm font-medium">Budgetstufen</Label>
                <div className="grid grid-cols-1 gap-2 mt-2">
                  {budgetOptions.map((option) => (
                    <Button
                      key={option.value}
                      variant={searchData.budgetType === option.value ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSearchData(prev => ({ ...prev, budgetType: option.value, customBudget: "" }))}
                      className="justify-start text-xs"
                    >
                      {option.label}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Custom Budget Input */}
              <div>
                <Label className="text-sm font-medium">Oder individuelle Budgetangabe</Label>
                <Input
                  placeholder="Budget in Euro (z.B. 1500)"
                  value={searchData.customBudget}
                  onChange={(e) => setSearchData(prev => ({ ...prev, customBudget: e.target.value, budgetType: "" }))}
                  type="number"
                  min="0"
                  className="mt-2"
                />
              </div>
            </CardContent>
          </Card>

          {/* Travel Period */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-lg">
                <Calendar className="w-5 h-5" />
                <span>Reisezeit (Optional)</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Select value={searchData.travelPeriod} onValueChange={(value) => 
                setSearchData(prev => ({ ...prev, travelPeriod: value }))
              }>
                <SelectTrigger>
                  <SelectValue placeholder="Wann möchten Sie reisen?" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="spring">Frühling (Mär-Mai)</SelectItem>
                  <SelectItem value="summer">Sommer (Jun-Aug)</SelectItem>
                  <SelectItem value="fall">Herbst (Sep-Nov)</SelectItem>
                  <SelectItem value="winter">Winter (Dez-Feb)</SelectItem>
                  <SelectItem value="flexible">Ich bin flexibel</SelectItem>
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {/* Travel Style */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-lg">
                <Sparkles className="w-5 h-5" />
                <span>Reisestil (Optional)</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {travelStyles.map((style) => (
                  <Badge
                    key={style}
                    variant={searchData.travelStyles.includes(style) ? "default" : "secondary"}
                    className={`cursor-pointer transition-colors ${
                      searchData.travelStyles.includes(style)
                        ? "bg-blue-600 text-white hover:bg-blue-700"
                        : "hover:bg-gray-300"
                    }`}
                    onClick={() => handleStyleToggle(style)}
                  >
                    {searchData.travelStyles.includes(style) && <X className="w-3 h-3 mr-1" />}
                    {style}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Additional Notes */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Zusätzliche Notizen (Optional)</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Besondere Anforderungen, Interessen oder Vorlieben..."
                value={searchData.additionalNotes}
                onChange={(e) => setSearchData(prev => ({ ...prev, additionalNotes: e.target.value }))}
                rows={3}
              />
            </CardContent>
          </Card>

          {/* Create Button */}
          <div className="sticky bottom-20 bg-white p-4 border-t border-gray-200 rounded-lg shadow-lg">
            <Button 
              onClick={handleCreateTrip}
              disabled={createTripMutation.isPending}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg"
              size="lg"
            >
              <Plus className="w-5 h-5 mr-2" />
              {createTripMutation.isPending ? "Erstelle Reise..." : "Reise erstellen"}
            </Button>
          </div>
        </div>
      </div>
    </Layout>
  );
}