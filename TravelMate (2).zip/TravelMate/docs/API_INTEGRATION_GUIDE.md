# API Integration Guide für TravelMate

## Übersicht der verfügbaren APIs

### 1. Flugbuchungen - Skyscanner API

**Verfügbarkeit in Replit:** ✅ Vollständig möglich
**Kosten:** Freemium (1000 Anfragen/Monat kostenlos)

```javascript
// Beispiel Integration
const SKYSCANNER_API_KEY = process.env.SKYSCANNER_API_KEY;

export const searchFlights = async (origin, destination, departDate, returnDate) => {
  const response = await fetch('https://partners.api.skyscanner.net/apiservices/v3/flights/live/search/create', {
    method: 'POST',
    headers: {
      'X-API-Key': SKYSCANNER_API_KEY,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      query: {
        market: 'DE',
        locale: 'de-DE',
        currency: 'EUR',
        query_legs: [
          {
            origin_place_id: { iata: origin },
            destination_place_id: { iata: destination },
            date: { year: 2024, month: 6, day: 15 }
          }
        ],
        adults: 1
      }
    })
  });
  return response.json();
};
```

### 2. Hotelbuchungen - Booking.com API

**Verfügbarkeit in Replit:** ✅ Vollständig möglich
**Kosten:** Kommissionsbasiert (keine Vorabkosten)

```javascript
// Beispiel Integration
const BOOKING_API_KEY = process.env.BOOKING_API_KEY;

export const searchHotels = async (destination, checkin, checkout, guests) => {
  const response = await fetch('https://distribution-xml.booking.com/json/bookings', {
    method: 'GET',
    headers: {
      'Authorization': `Basic ${Buffer.from(BOOKING_API_KEY).toString('base64')}`,
      'Content-Type': 'application/json'
    },
    params: {
      city_ids: destination,
      checkin: checkin,
      checkout: checkout,
      guest_qty: guests,
      currency: 'EUR'
    }
  });
  return response.json();
};
```

### 3. Aktivitäten & Touren - GetYourGuide API

**Verfügbarkeit in Replit:** ✅ Vollständig möglich
**Kosten:** Kommissionsbasiert

```javascript
// Beispiel Integration
const GETYOURGUIDE_API_KEY = process.env.GETYOURGUIDE_API_KEY;

export const searchActivities = async (location, category) => {
  const response = await fetch('https://api.getyourguide.com/activities', {
    method: 'GET',
    headers: {
      'X-API-Key': GETYOURGUIDE_API_KEY,
      'Accept': 'application/json'
    },
    params: {
      location: location,
      category: category,
      currency: 'EUR',
      language: 'de'
    }
  });
  return response.json();
};
```

### 4. Mietwagen - Rentalcars.com API

**Verfügbarkeit in Replit:** ✅ Vollständig möglich
**Kosten:** Kommissionsbasiert

```javascript
// Beispiel Integration
export const searchRentalCars = async (location, pickupDate, returnDate) => {
  const response = await fetch('https://www.rentalcars.com/FTSBookingEngine/InternalLocationSearch_v4', {
    method: 'GET',
    headers: {
      'Accept': 'application/json'
    },
    params: {
      location: location,
      pickupdate: pickupDate,
      returndate: returnDate,
      currency: 'EUR'
    }
  });
  return response.json();
};
```

## Integration in TravelMate

### Server-seitige API-Routen hinzufügen

```javascript
// server/external-apis.ts
import express from 'express';

const router = express.Router();

// Flugsuche
router.get('/flights/search', async (req, res) => {
  try {
    const { origin, destination, departDate, returnDate } = req.query;
    const flights = await searchFlights(origin, destination, departDate, returnDate);
    res.json(flights);
  } catch (error) {
    res.status(500).json({ error: 'Flugsuche fehlgeschlagen' });
  }
});

// Hotelsuche
router.get('/hotels/search', async (req, res) => {
  try {
    const { destination, checkin, checkout, guests } = req.query;
    const hotels = await searchHotels(destination, checkin, checkout, guests);
    res.json(hotels);
  } catch (error) {
    res.status(500).json({ error: 'Hotelsuche fehlgeschlagen' });
  }
});

export default router;
```

### Frontend-Integration

```javascript
// client/src/lib/externalApis.ts
export const bookingService = {
  async searchFlights(searchParams) {
    const response = await fetch('/api/external/flights/search?' + new URLSearchParams(searchParams));
    return response.json();
  },
  
  async searchHotels(searchParams) {
    const response = await fetch('/api/external/hotels/search?' + new URLSearchParams(searchParams));
    return response.json();
  },
  
  async bookTrip(tripData) {
    const response = await fetch('/api/external/book', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(tripData)
    });
    return response.json();
  }
};
```

## Implementierung in der Reiseplanung

### 1. One-Click-Buchung aktivieren

```javascript
// In Search.tsx - KI-Automatisierte Buchung
const handleAIBooking = async () => {
  setBookingStep('searching');
  
  try {
    // 1. Flüge suchen
    const flights = await bookingService.searchFlights({
      origin: userLocation,
      destination: searchData.countries[0],
      departDate: searchData.startDate,
      returnDate: searchData.endDate
    });
    
    // 2. Hotels suchen
    const hotels = await bookingService.searchHotels({
      destination: searchData.countries[0],
      checkin: searchData.startDate,
      checkout: searchData.endDate,
      guests: getGuestCount(searchData.groupSize)
    });
    
    // 3. Aktivitäten suchen
    const activities = await bookingService.searchActivities({
      location: searchData.countries[0],
      category: searchData.travelStyles
    });
    
    // 4. Optimale Kombination finden
    const bestCombo = await bookingService.findBestCombination({
      flights, hotels, activities,
      budget: getBudgetAmount(searchData.budgetType, searchData.customBudget),
      preferences: searchData.travelStyles
    });
    
    // 5. Automatisch buchen
    const booking = await bookingService.bookTrip(bestCombo);
    
    setBookingStep('completed');
    
  } catch (error) {
    setBookingStep('error');
  }
};
```

### 2. Live-Preisüberwachung

```javascript
// Preisalarme für gespeicherte Reisen
const setupPriceAlerts = async (tripId) => {
  const response = await fetch('/api/price-alerts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ tripId, alertThreshold: 0.1 })
  });
};
```

## Umgebungsvariablen Setup

```bash
# .env (in Replit Secrets)
SKYSCANNER_API_KEY=your_skyscanner_key
BOOKING_API_KEY=your_booking_key
GETYOURGUIDE_API_KEY=your_getyourguide_key
AMADEUS_API_KEY=your_amadeus_key
AMADEUS_API_SECRET=your_amadeus_secret
```

## Kostenschätzung

| Service | Kostenmodell | Monatliche Kosten (1000 Buchungen) |
|---------|--------------|-------------------------------------|
| Skyscanner | Freemium + Pay-per-use | €50-200 |
| Booking.com | Kommission (15-25%) | €0 Vorabkosten |
| GetYourGuide | Kommission (20-30%) | €0 Vorabkosten |
| Amadeus | Pay-per-call | €100-300 |

## Implementierungsschritte

1. **API-Schlüssel beantragen** (1-2 Wochen)
2. **Backend-Integration** (1 Woche)
3. **Frontend-Komponenten** (1 Woche)
4. **Testing & Optimierung** (1 Woche)
5. **Produktionsdeployment** (3 Tage)

## Sicherheitsmaßnahmen

- Alle API-Schlüssel in Replit Secrets speichern
- Rate Limiting implementieren
- Fehlerbehandlung für API-Ausfälle
- Backup-APIs für kritische Services
- Logging aller API-Calls für Debugging

## Fazit

Die Integration externer APIs in Replit ist vollständig möglich und ermöglicht:
- ✅ Echte Flug-, Hotel- und Aktivitätsbuchungen
- ✅ Live-Preisvergleiche
- ✅ Automatisierte One-Click-Buchungen
- ✅ Kommissionsbasierte Monetarisierung
- ✅ Skalierbare Architektur

Die Implementierung erfordert nur die entsprechenden API-Schlüssel und kann schrittweise erfolgen.